
## Hans Rutger Bosker, Max Planck Institute, Nijmegen
## R tutorial, lecture 1, 23 May 2017
## HansRutger.Bosker@mpi.nl


## FOR INSTRUCTOR:
# CLASSROOM PRESENTATION PREFERENCES
# increase font size (18+) and adjust color (red4) for Console window
# R win: use Rgui > preferences > gui
# Rstudio: tools > options > appearance


# Session 1 ---------------------------------------------------------------

# Rstudio environment -----------------------------------------------------

# Rstudio is an IDE for R.

# source pane, with tabs
#   - section outline
#   - datasets
# console
# environment pane
# files, plots, packages, help pane

# R studio projects
#   - keeps track of working directory for you
#   - compatible with git(hub)
#   - allows you to have multiple Rstudio sessions open at once with different workspaces
#   - keeps track of settings

# lets make a new Project and associate it with the correct working directory:
# File > New Project...

# Open the .RProj file to open RStudio with your project loaded, or select from the
# dropdown menu in the top right of the RStudio window.

# Getting started ---------------------------------------------------------

# Download all the course materials from
# http://www.mpi.nl/people/bosker-hans-rutger/teaching
# Make sure you save all materials inside one and the same folder
# so R can easily find and use the code, datafiles, etc.
# Make sure you use Rstudio to open the .Rdata file.

# You can simply use R as a calculator.
# For instance, move your cursor to the code lines below
# and hit CTRL-ENTER to enter these lines into the Console window below.
2*3/4
cos(1*pi)
log(144)

# This is the typical way of using R: you write a script
# that contains all your code and you simply pass the
# commands to the Console window.
# You can also enter commands directly into the Console window, if you like,
# but after you've then closed R, you've lost track of what you did.
# So use scripts!
# BTW, in the Console window you can use the Arrow Up key to restore old commands.

# OK, now create your first very own variable
a <- 25
# This basically means "store the value 25 inside this variable called a".
# Note that in the Workspace window (top right) you can keep
# track of all the variables in your Workspace.

# Using R as a calculator -------------------------------------------------

# Now we're ready to get started!

# The first use of R is as a calculator
# (reminder: use CTRL-ENTER to copy commands into the Console window)
1
# [1] 1				<- this is the output that you'll see in the Console window
1+1
# [1] 2
1*4
# [1] 4
3^3
# [1] 27
sqrt(25)
# [1] 5
# standard operators: +-*/^
# other operators: integer division and modulo
# there are 49 items and 3 groups, how many items per group? 
49 %/% 3  # integer division, returns 16
# how many items remaining after integer division? 
49 %% 3 # returns 1
# 49 == (16*3)+1



# But this is all not very interesting,
# because we can't do complex calculations this way.
# For this we need variables. These are called objects in R.
a <- 25
# This gives no output, because we're just telling R that we want
# to create a variable.
# Only when we query a variable by simply entering its name, does R print output
a

b <- a*2		# no output
b				    # output = 50
sqrt(b/a)		# output = 1.414214

# Variables do not have to be numbers.
# Variables can also be strings:

a <- "This is the first part"
# NOTE: there is no Undo command, previous a is lost!
b <- "of a longer sentence."
c <- paste(a, b, sep=" ")
c

# Variables can also be lists of numbers, called vectors.
a <- c(1,25) # the c function is for combine
# combine the values 1 and 25 and store in object a 
a
# Use , to mean AND
# Use : to mean each integer in between 1 and 25
a <- c(1:25)
a
b <- c(26:50)
b

# The colon : is shorthand for a longer function seq()
b <- seq(from=26,to=50,by=1)
b

# you can perform calculations on vectors
c <- a+b
c
mean(c)
sd(c)
summary(c) # print numerical summary
# Note that a+b will add value1 of a to value1 of b, etc.
# If you want to combine a and b, use:
c <- c(a,b)

objects() # list all objects in workspace
rm(c) # remove objects from workspace
objects() 
# Notice their removal in the window in the top right; remember NO UNDO!

# So far, we've been using the operate <- to store values inside an object.
# Instead of the operator <- one can also use =
x = c(51:75)
# =		means 'assign': assign these values to this object
# ==	means 'query': does this object equal these values?
x == c(51:75) # Does the vector c(51:75) equal the values inside x?
# Output = 25 times TRUE.
25 == 50/2 # output = TRUE
25 = 50/2  # This means: assign 50/2 to the variable 25.
# However, you cannot use numbers as variable names, so R will give an error.

# The problem with the operator = is that it does not have a clear 'direction'
b = a # Is a replaced with b, or b replaced with a?
# therefore, use <-



# Vectors of strings:
a <- c("one","two","three")
a

mean(a) # ERROR!
summary(a)

# Accessing a vector's elements with square brackets [ ]
a[1]
# [1] "one"
a[1:2]
# [1] "one" "two"
a[c(1,3)]
# [1] "one" "three"
a[c(1:3)]
# [1] "one" "two" "three"

# Replacing a vector's elements
a[2] <- "substituted"
a





### BOOLEAN or LOGICAL VARIABLE

x = c(51:75)
x
xf <- (x<55)
class(xf)
xf




### DATA FRAMES
# For psycholinguists, the most used variable is the dataframe.
# A dataframe is basically a table consisting of rows and columns with data inside
xxf <- data.frame( x, xf ) # bind variables into data frame = worksheet
# This dataframe is only small so it's easy to look inside
xxf
# However, for experimental data with thousands of observations and multiple columns
# printing the entire dataframe is not very insightful.
# Therefore: very useful for quick view of objects
str(xxf) # show structure of data frame
head(xxf) # show first 6 lines of data frame
tail(xxf) # show last 6 lines of data frame
sapply(xxf,class) # show class, for each element=column in xxf




### Missing values

var(xxf$x)

xxf[c(11,20:21),1] <- NA # replace 3 obs by NA = 'not available' 
xxf

which(is.na(xxf$x)) # which NA obs
table( is.na(xxf$x) ) # how many NA obs
mean(xxf$x, na.rm=T) # excluding NA obs
mean(xxf[!is.na(xxf$x),1])

xxf[is.na(xxf$x),] <- mean(xxf[!is.na(xxf$x),1]) # replace NA by mean
var(xxf$x) # replacing NA by mean has reduced variance !! 



# Excercises with Vectors -------------------------------------------------

# Create the following variables:
# obj1 containing all even numbers from 1 to 100. Use seq().
# obj2 containing all uneven numbers from 1 to 100. Use obj1 to create obj2.
# obj3 containing all numbers from 1 to 50. Use obj1 to create obj3.
# obj4 containing a repeating sequence from 1 to 50, total length 1000. Use c and rep().
# obj5 where the 11th element of obj4 is changed to 200.
















# QUERYING DATAFRAMES ----------------

#  Now let's read some real data

# Let's read the data in R
# read.table: read data from file
lexdec <- read.table(file="session_1/lexdec.txt", header=TRUE)
# These data were adopted from the lexdec dataframe from the languageR package.
# They contain RT data (already log transformed) for 79 words from 21 subjects, see Baayen (2008).

lexdec # prints the entire table, but rather large for screen;
# therefore we explore the data with R

dim(lexdec) # always double-check dimensions of rows and columns
nrow(lexdec) # number of rows
ncol(lexdec) # number of columns
head(lexdec) # quick view of what the object looks like
str(lexdec)
dimnames(lexdec)	# row & column names
dimnames(lexdec)[[2]]	# only column names

# This dataset contains 1659 rows and 11 columns.
# Each row is one observation; one trial from one particular participant.
summary(lexdec$Subject)
length(summary(lexdec$Subject))
21 * 79
# so each of the 21 pps was presented with 79 trials.



# As with vectors, you can use square brackets [ ] to query
# data inside a dataframe.
# Note: the two dimensions of the dataframe are separated by ,
lexdec[1, ] # first row, all columns
lexdec[ ,1] # first col, all rows
lexdec[ c(3:5), c(1,5) ] # rows 3 to 5 of columns 1 & 5

# you can also query particular conditions
lexdec[lexdec$Sex=="F",] # give me all columns of only those rows for which sex==1
# this is often used for subsetting
lexdec_female <- lexdec[lexdec$Sex=="F",]
dim(lexdec)
dim(lexdec_female)

# Instead of using column numbers, you can also refer to column names
# with the operator $
lexdec$Length
mean(lexdec$Length)
summary(lexdec$Length)

# Note that columns contain different types of data classes.
class(lexdec$Subject)	# factor
class(lexdec$Trial) # integer
class(lexdec$RT)	# numeric

# creating new columns
lexdec$Block <- "firstblock" # new column containing 1659 times the value 1
# Now overwrite the contents of the column Block for only those rows for which Trial>40
lexdec[lexdec$Trial>40,]$Block <- "secondblock"
head(lexdec)
tail(lexdec)
lexdec[c(35:45),]


class(lexdec$Block)	# character (just text)
summary(lexdec$Block)  # character (just text)
lexdec$Block <- as.factor(lexdec$Block)
class(lexdec$Block)	# factor
summary(lexdec$Block)  # factor with two levels

# now let's write the entire dataset with our new column Block
# to a file in your folder

write.table(lexdec, file="lexdec_withnewcolumn.txt")

# You'll see a new file appear in your folder.




lexdec$Block <- NULL # remove columns you don't need
# CAREFUL: NO UNDO!
# Note: only removed in R, not in your file you just saved

# you can also use the square brackets to replace particular data points
lexdec[lexdec$Subject=="K", ] # nothing behind comma, so give me all columns
lexdec[lexdec$Subject=="K", ]$Sex <- "M"
lexdec[lexdec$Subject=="K", ]

mean(lexdec$RT)
#[1] 6.38509
sd(lexdec$RT)
#[1] 0.2415091
sd(lexdec[lexdec$RT<6.3,]$RT)
#[1] 0.08992153




### TABLES

# use table for numbers of cases
table( lexdec$Sex, lexdec$NativeLanguage ) # table of two variables, 
# cells contain numbers of observations
with(lexdec, table( Sex, NativeLanguage ) ) # same, less typing 

# in order to avoid having to type your main data object over and over again
# you can also use
attach(lexdec) # now R knows you mean to query lexdec and not other objects
mean(RT) # instead of mean(lexdec$RT)
detach(lexdec) # detaches lexdec
mean(RT) # doesn't work anymore, because there is no object RT
# because people tend to forget detaching objects, which may cause misinterpretation,
# it's often better to use: with(lexdec, ...)

# use tapply for applying function to data in each cell
# apply function sd on age, broken down by cells defined by list()
# variables are defined within scope of lexdec
with(lexdec, tapply( RT, list(Sex,NativeLanguage), mean ) )
with(lexdec, tapply( RT, list(Sex,NativeLanguage), sd ) )

### HELP
?mean # help for the function mean() with examples
??"standard deviation" # search for string




# Exercises with dataframes -----------------------------------------------

# Read the help page of the function cor.test()
# Calculate the correlation between RT and Frequency
# Calculate how many RT outliers (>2SD) there are.
# Calculate the correlation between RT and Length, after excluding the outliers.
# Calculate the average RT (and SDs) for each Class of words, after excluding the outliers, and only of the correct trials.
# Read the help page of the function substr()
# Create a new column FirstLetterG that contains all zeros, except when the Word starts with the character 'g'
# Calculate the average RT (and SDs) for words beginning with 'g'


# lists -------------------------------------------------------------------

# A list is an object that can contain a mixture of types.

sample_list <- list("cabbage",34,"precision",c(34,56,32),data.frame("x"=c(12,34,12,45),y=c(65,34,12,23)))

# you refer to each item with double square brackets: [[1]]

sample_list[[3]] # = "precision"

# the elements can also be named:

sample_list <- list("vegetable"="cabbage",
                    "number"=34,
                    "quality"="precision",
                    "vector"=c(34,56,32),
                    "data"=data.frame("x"=c(12,34,12,45),y=c(65,34,12,23)))

# then you can refer to them with the $ operator

sample_list$data

# (technically, a data.frame is a special case of a list. But you don't need to know that.)

# inferential statistics --------------------------------------------------

## some very simple hypothesis testing

#H1: L1 speakers have shorter RTs than non-natives
#H0: L1 == L2
t.test(lexdec$RT ~ lexdec$NativeLanguage, paired=F)

#regression
#always start with scattergrams ! 
with(lexdec,  plot(Frequency, RT) )
with(lexdec, cor.test(Frequency, RT))

model1.lm <- lm(RT ~ Frequency, data=lexdec)
summary(model1.lm)
# what does intercept mean?
median(lexdec$Frequency)
model2.lm <- lm(RT~I(Frequency-4.75359), data=lexdec)
summary(model2.lm)
# when centered around median, intercept changes


# plotting with base R ----------------------------------------------------

# plotting with base R is mostly quicker than ggplot for simple exploratory plots, but ggplot 

# creating your own functions
square <- function(x) {
  x*x
}
# and using them for plotting, for instance
plot(1:10, square(1:10), type="b", col=rainbow(10), pch=15, cex=2 )



boxplot(lexdec$RT, col="red", varwidth=T, xaxt="n", ylab="log RTs")
fivenum(lexdec$RT) # min, Q1, median, Q3, max
boxplot.stats(lexdec$RT) # lower cutoff, Q1, median, Q3, upper cutoff
abline( h=c(6,6.5,7), col="grey", lty=2 ) # horizontal grid lines, lty=2 means dashed lines.

boxplot(lexdec$RT ~ lexdec$Word, col="lavender", varwidth=T, ylab="log RTs")

# useful plotting link for simple graphs: https://www.harding.edu/fmccown/r/ 

# We'll cover some more advanced graphics in lecture 2.

# package management ------------------------------------------------------

#Packages tab > Install...

# This command will NOT work
lmer1 <- lmer(RT ~ Frequency * Length + (1|Subject), data=lexdec)
# because the function lmer() is only available in the package lme4
# Download it (once)
# and load it (every time you open R)

library(lme4)
# can also click check boxes in packages pane

# Now it will work
lmer1 <- lmer(RT ~ Frequency * Length + (1|Subject), data=lexdec)
summary(lmer1)
# Don't worry, we'll cover this topic in lecture 3...



### SAVING YOUR WORK 

# RStudio: normal file save and file open.

# saving single data objects: as R objects (only readable by R), extension .Rda
save(xxf, file="xxf.Rda")
load(file="xxf.Rda") # recreates object that was saved in xxf.Rda

# saving data objects: as exported text files; much more useful
write.table(lexdec_female, file="lexdec_female.txt", row.names=F, col.names=T)
# if you need more options, just check ?write.table


