
## Joe Rodd, Max Planck Institute, Nijmegen
## R tutorial, lecture 2, 1 June 2017
## Joe.Rodd@mpi.nl


# Session 2 ---------------------------------------------------------------

# read in some data -------------------------------------------------------

library(readxl)
library(dplyr)

# you might have data in several formats that you need to read in to R.

# some handy functions for that are:

# `read_excel()` from the `readxl` package: reads excel data. You can specify which sheet to read in and whether to
#                                           skip any lines at the beginning of the sheet. Makes a good attempt to 
#                                           detect header.

final_2016 <- read_excel("session_2/eurovision/ESC-2016-grand_final-full_results.xls",skip = 1,sheet = 1)
semi_final1_2016 <- read_excel("session_2/eurovision/ESC-2016-first_semi-final-full_results.xls",skip = 1,sheet = 1)
jury_final_2016 <- read_excel("session_2/eurovision/ESC-2016-grand_final-full_results.xls",sheet = 2)

# `read_delim()`:                           reads CSV-type files. You can specify the delimiter (comma, semicolon, space etc)
#                                           and whether there is a header (column titles) or not

countries <- read.delim("session_2/eurovision/countries.csv",sep = ";")

# column names with spaces are really annoying, so we will change them the dplyr way

final_2016 <- final_2016 %>% transmute(from = `From country`,
                                       to = `To country`,
                                       A = `Jury A`,
                                       B = `Jury B`,
                                       C = `Jury C`,
                                       D = `Jury D`,
                                       E = `Jury E`,
                                       jury_rank = `Jury Rank`,
                                       televote_rank = `Televote Rank`,
                                       jury_points = as.numeric(`Jury Points`),
                                       televote_points = as.numeric(`Televote Points`))

semi_final1_2016 <- semi_final1_2016 %>% transmute(from = `From country`,
                                                   to = `To country`,
                                                   A = `Jury A`,
                                                   B = `Jury B`,
                                                   C = `Jury C`,
                                                   D = `Jury D`,
                                                   E = `Jury E`,
                                                   jury_rank = `Jury Rank`,
                                                   televote_rank = `Televote Rank`,
                                                   jury_points = as.numeric(`Jury Points`),
                                                   televote_points = as.numeric(`Televote Points`))


# We'll explain first how dplyr works, then come back to examine what we did here.


# dplyr -------------------------------------------------------------------

# dplyr aims to provide a function for each basic verb of data manipulation:
#
# filter() to select cases based on their values.
# arrange() to reorder the cases.
# select() and rename() to select variables based on their names.
# mutate() and transmute() to add new variables that are functions of existing variables.
# summarise() to condense multiple values to a single value.
# sample_n() and sample_frac() to take random samples.

# We might for instance only be interested in scores awarded to the Netherlands. We would then filter the dataset.

final_2016 %>% filter(to=="The Netherlands")

# We used a new operator, %>%. This is a piping operator, which 'pipes' the output of the function on the left into the function on the right:
#           data %>% step1() %>% step2() %>% step3()
#           step3(step2(step1(data)))
# the idea is that it is more legibile when you have a complicated set of commands. 
# so we piped our data, final_2016 to the filter function.
# the filter function selects rows where the conditions you specify are met. Here we specified that the column `to` should be precisely
# "The Netherlands". We can also use other comparison operators:

final_2016 %>% filter(to=="The Netherlands",televote_points>=8)

# Now we've selected rows where `to` is precisely equal to "The Netherlands" _and_ where `televote_points`
# was greater or equal to 10.

# Poor Dutch people have nearly as few friends as the British.

final_2016 %>% filter(to=="United Kingdom",televote_points>=8)



# If you have more rows to work with, then you might like to order them:

final_2016 %>% filter(to=="Ukraine",televote_points>=8) %>% arrange(-televote_points)

# we can also order within each level:

final_2016 %>% filter(to=="Ukraine",televote_points>=8) %>% arrange(-televote_points,-jury_points)

# Imagine we wanted to know how many times each country was awarded 12 points by the televoters. 
# first we'd need to filter to only select the rows where 12 points were awarded.

final_2016 %>% filter(televote_points == 12)

# now we need to how many times each country appears in the 'to' column in this list. We can do
# that using `group_by()` and `summarise()`.
# `group_by()` allows us to specify the structure in the dataset but doesn't change anything else
# `summarise()` essentially breaks up the data.frame into smaller data.frames (one for each group)
# then runs the functions we specify on each of those data.frames. It makes a new data.frame, with one
# row for each combination of grouping variables, and one column for each of the output variables we
# specify in the call to `summarise()`. all `n()` does is count the number of rows in that mini data.frame.

number_of_twelves <- final_2016 %>% group_by(to) %>% filter(televote_points == 12) %>% summarise(how_many = n())

# we could also easily calculate for each country the average number of points awarded. We can do this with the 
# normal `mean()` function. We'll specify that NA values should be excluded from the calculation (otherwise the
# function just returns an NA itself):

 final_2016 %>% group_by(to) %>% summarise(average_score = mean(televote_points,na.rm = T)) -> average_score

# notice the -> operator. This is the same as the <- operator, but the other way round (i.e. you specify
# the name of the object to create on the right hand side, rather than the left). I prefer to avoid this, because
# it can make it harder to find where you assign a variable when you look back over your code.

# Imagine we wanted to know if the average score was correlated with the number of twelves recieved.
# we can do that by joining these two new data.frames together.

# there are several types of join. Each join function makes one data.frame out of two. Columns with the
# same name are conflated, and columns that only exist in one of the original data.frames are retained.

# inner_join(x, y)     Join x and y, retaining only rows that were present in both tables
# left_join(x, y)      Join x and y, retaining all rows in x 
# right_join(x, y)     Join x and y, retaining all rows in y 
# full_join(x, y)      Join x and y, retaining all rows in both x and y

joined <- inner_join(number_of_twelves,average_score)

# semi-dumb joining of rows

final_and_semi_2016 <- bind_rows(final_2016,semi_final1_2016)

# lets have a look at the correlation in ggplot()

library(ggplot2)

ggplot(joined) + geom_point(aes(x=how_many,y=average_score))

# we'll come back to ggplot later

cor.test(joined$how_many,joined$average_score)

#quite correlated...


# tidy data ---------------------------------------------------------------

# This dataset isn't optimally structured to be able to make use of the data about the scores from the Jurors. 
# We should always strive for a "tidy" structure to our data. We should aim for tidy data where:


#       each variable is in a column
#       each observation is a row
#       each value is a cell

# At the moment, our data about the Juror's scores breaks the second rule: we have data from multiple observations
# (scores by jurors) spread across multiple rows. (this is also called the wide form)
# We'll use the `tidyr` package to fix that.

library(tidyr)

# First we use dplyr::select() to select the columns that we're interested in

final_2016 %>% select(from, to, A, B, C, D, E)

# Then we use gather (this lives in the `tidyr` package) to reshape our data into the long form.

scores_by_juror <- final_2016 %>% select(from, to, A, B, C, D, E) %>%
  gather(key = juror,value=rank, A, B, C, D, E)

# we told it to gather columns A, B, C, D and E, and put the keys into a column called `juror`, and the values
# into a column called `rank`.

# We also have biographical information about the jurors in another data.frame (`jury_final_2016`)
# we can join these data.frame together.

# first we'll need to restructure the data about the jurors slightly. We'll do this with another dplyr function,
# `transmute()` (which we also used earlier).

# `transmute()` and `mutate()` are similar. They allow adding or replacing the columns of a data.frame.
# it is possible to apply most functions to each column during `mutate()` or `transmute()`. The difference
# between the two is that `mutate()` retains the existing columns, whilst transmute excludes (aka drops) columns
# not explicitly mentioned.

library(stringr) # for doing things with character strings

jury <- jury_final_2016 %>% transmute(from = Country,
                                      juror = `Jury member`,
                                      name = `Full name`,
                                      Gender,
                                      Age,
                                      is.singer = str_detect(tolower(Profession),"singer"),
                                      is.songwriter = str_detect(tolower(Profession),"songwriter"))

# here we have created new columns for `from`, `juror`, `is.dj` etc. Some of them are simply the same as existing
# columns. if we want to retain a column, we can just include it without an =.
# To detect different professions, we can use the `str_detect(string, pattern)` function from `stringr`. This
# gives a true valueif `pattern` is found in `string`, otherwise it gives a false value. `string` must be a
# character vector (or column, in our case). We first make all the text lower case by `tolower(Profession)`.


# now we can join the two tables together and see which ranks which jurors assigned.

scores_by_juror_details <- left_join(scores_by_juror,jury)

# it might be interesting to know if DJs preferred different songs to songwriters.
# Let's calculate the average score for each song awarded by DJs and awarded by songwriters, and see if 
# the top 3 in each differ.

scores_by_juror_details %>% filter(is.dj) %>% group_by(to) %>%
  summarise(mean_rank=mean(rank)) %>% arrange(mean_rank)
scores_by_juror_details %>% filter(is.songwriter) %>% group_by(to) %>%
  summarise(mean_rank=mean(rank)) %>% arrange(mean_rank)


# spread is the inverse of gather (i.e. it makes multiple columns with results from one column of labels and
# one column of results). This is often handy to calculate proportions.

scores_by_juror %>% spread(key = juror,value = rank)

# We can also use `sample_n()` to select n sample rows from a data.frame. (this function actually
# comes from dplyr)

scores_by_juror %>% sample_n(5)

# mini-assignment 1 --------------------------------------------------------

# The results for the 2017 contest are recorded in a different format. Read the results from the first 
# sheet of the file session_2/eurovision/ESC2017_GF_Results.xlsx, and use dplyr and tidyr functions
# to transform it into a tidy data.frame (i.e. one observation per row, one variable per column).

# Then, read in the populations of the countries from the csv file "countries.csv" to a data.frame

# Join these two data.frames. Scale the points to account for the population of each country
# hint: each country awards 114 points, and there are 42 voting countries.

# ggplot2 -----------------------------------------------------------------

# lets do some plotting to see if the scores awarded to the winning act, Ukraine, vary by gender and age of the
# jurors.

  ggplot(scores_by_juror_details %>% filter(to=="Ukraine"), aes(x=Age,y=rank)) +
  geom_point(aes(colour=is.singer))+ # make a geom_point layer
  geom_smooth(linetype = 3, method = lm)+ # make a geom_smooth layer
  facet_wrap(~Gender,ncol = 1)

# not really... but we can still deconstruct that plotting call.

# 
# Compared to base graphics, ggplot2:
#   - is more verbose for simple / canned graphics
#   - is less verbose for complex / custom graphics
#   - does not have methods (data should always be in a data.frame)
#   - uses a different system for adding plot elements

# The first key concept in ggplot is that of 'aesthetics'. An aesthetic is a visual property of 
# the display of the data; for instance
#   - x, y:  the location on the x-axis or y-axis
#   - colour (you can also type color): the colour of points
#   - linetype: the dashing / dotting of lines
#   - fill: fill colour
#   - size: the size of points
#   - shape: the shape of points
#   - alpha: transparency
  
# We can map columns in the data to the aesthetics or we can assign static values to them.
# to map columns to aesthetics, we use a function, `aes(aesthetic = column ...)`.
  
aes(x = Age, y = rank)

# the second key concept is geoms (aka layers). A geom is a means of displaying the data according to the
# aesthetics specified, for instance:
#   - geom_point: scatter points
#   - geom_line: lines
#   - geom_violin: violins
#   - geom_density: distributions
#   - geom_smooth: model fits with confidence intervals for scatter points
#   - geom_text: textual labels at each data point
#   - geom_bar: yes, it exists
  
# not all geoms use all the aesthetics.
  

# lets now deconstruct the previous plotting call:

# we start by calling ggplot:
# ggplot(data, aesthetics common to all geoms)

ggplot(scores_by_juror_details %>% filter(to=="Ukraine"), aes(x=Age,y=rank))

# without any geoms, the axes get prepared, but no data gets plotted, because we haven't
# yet specified how that should happen.
  
# Lets a geom. We link the ggplot call and the geom call with a +.

ggplot(scores_by_juror_details %>% filter(to=="Ukraine"), aes(x=Age,y=rank))+
  geom_point()

# we could also have put the aes call in the geom and got the same result:

ggplot(scores_by_juror_details %>% filter(to=="Ukraine"))+
  geom_point(aes(x=Age,y=rank))

# all the geoms 'inherit' the aesthetics that you put in the ggplot call. It usually saves typing
# to put the x and y aesthetics in the ggplot call, because often you will use the same aesthetics on
# all the geoms in a plot. You can add aesthetics that are only relevant for one geom in the call for that geom.

# to assign a fixed value to an aesthetic, you specify the value you want outside the `aes()` call, but inside the `geom_X()` call.

ggplot(scores_by_juror_details %>% filter(to=="Ukraine"))+
  geom_point(aes(x=Age,y=rank), shape = 4, colour = "purple")

# shapes and linetypes have arbitrary numbers, colours have fairly logical names, or you can use codes of the 
# type '#FFFFFF'. A good resource is http://www.cookbook-r.com/Graphs/Shapes_and_line_types/.

# you can have as many geoms as you like, chained together with +:

ggplot(scores_by_juror_details %>% filter(to=="Ukraine"),aes(x=Age,y=rank))+
  geom_smooth(linetype = 3, method = lm)+
  geom_text(aes(label=from),colour="#00FF66")+
  geom_point(aes(colour=is.singer))

# Beautiful.

# some geoms, like `geom_smooth()`, have methods and other parameters that you need to set. Here, we specify
# that we'd like it to fit a linear regression (function `lm()`) to the data to generate our fit line.

# Another really powerful feature is faceting. This divides the plot up into panels according to the data.
# there are two faceting functions:

#   - facet_wrap(~ factor): split by one factor
#   - facet_grid(factor_vertical_axis ~ factor_horizontal_axis): split by two factors and make a grid

# these functions borrow the ~ (by) operator from model specifications.

ggplot(scores_by_juror_details %>%
         filter(to=="Ukraine"), aes(x=Age,y=rank)) + # call ggplot (we've piped the data in here)
  geom_point(aes(colour=is.singer))+ # (3) make a geom_point layer
  geom_smooth(linetype = 3, method = lm)+ # (4) make a geom_smooth layer
  facet_grid(is.songwriter~Gender)



# Here's another example:

final_scores <- final_2016 %>% group_by(to) %>%
  summarise(total_points = sum(televote_points,na.rm = T) + sum(jury_points,na.rm = T)) %>% arrange(total_points)


# first, we calculate the final scores using dplyr functions, and order the resulting table 
# by the total points each song gained.

ggplot(scores_by_juror, aes(x=to,y=rank))+
  geom_violin(aes(fill=to))+
  scale_fill_discrete(guide=F)+
  scale_y_continuous(name="Rank (1 = best)")+
  scale_x_discrete(name="Entrant",limits=final_scores$to)+
  coord_flip()

# here we've used another feature of ggplot, scales and coords. The two are rather similar in the 
# effects that they produce.
# by specifying a scale, we can control further how the aesthetics are mapped to the geoms.
# There is one scale for each aesthetic. Scales can be either continuous or discrete, 
# reflecting whether the data that they are representing is continuous or discrete. 
# We can specify whether a `guide` (legend) is displayed for each scale. 
# coordinates, on the other hand concern how The scales are plotted onto the page. Coordinates might be 
# things like log transformations, or flips of the data.

# here's how the plot looks without specifying the scales:

ggplot(scores_by_juror, aes(x=to,y=rank))+
  geom_violin(aes(fill=to))


# to output a plot, we use the pdf() and png() functions.

pdf("save_plot.pdf",paper = "a4")
ggplot(scores_by_juror, aes(x=to,y=rank))+
  geom_violin(aes(fill=to))+
  scale_fill_discrete(guide=F)+
  scale_y_continuous(name="Rank (1 = best)")+
  scale_x_discrete(name="Entrant",limits=final_scores$to)+
  coord_flip()
dev.off()

# pdf knows about paper sizes, or dimensions in inches.
# the pdfs created can be opened in illustrator for further editing or incorporation into posters.

png("save_plot.png",width = 800,height = 700)
ggplot(scores_by_juror, aes(x=to,y=rank))+
  geom_violin(aes(fill=to))+
  scale_fill_discrete(guide=F)+
  scale_y_continuous(name="Rank (1 = best)")+
  scale_x_discrete(name="Entrant",limits=final_scores$to)+
  coord_flip()
dev.off()

# png expects dimensions in pixels.


# mini-assignment 2 -------------------------------------------------------

# Find jurors who are djs, and exclude them.
# Plot the remaining jurors by age and rank awarded to a country of your choice.


# ugly data ---------------------------------------------------------------

library(tidyr)

# such as this data from Eyelink:

messages <- read.delim("session_2/messagerep.xls")

# There is information we need embedded in the messages data.frame in the column CURRENT_MSG_TEXT,
# such as the condition (456, 646 or 915). We can use various R functions to extract this.

# The stringr package is useful for this. We've already seen `str_detect()`, which returns true if a
# pattern is present in a column. The patterns are regex patterns.
# str_match returns the part that matches, then each search group ( ).

messages <- messages %>% mutate(condition = str_extract(CURRENT_MSG_TEXT,"456|646|915"),
                    trial_number = str_match(CURRENT_MSG_TEXT,"\\d\\d\\d_(\\d+)")[,2],
                    event = str_extract(CURRENT_MSG_TEXT,"cue\\d|fixation_cross|pictures_presented"))


# loops and conditionals --------------------------------------------------

# automate repetitive things with a for loop

# a for loop loops over a vector:.

colours <- c("blue","green","yellow","purple","lilac")

# a for loop is opened with the following code `for(interator in vector){ }`
# whatever is wrapped in { } gets repeated for each element of the vector.
# the iterator variable gets set to each element of the vector in turn:

for(colour in colours){
  print(colour)
  print(nchar(colour))
}

# you could also use seq and rep:

for(code in seq(1,40,2)){
  print(code/60)
}

# conditionals have a similiar structure:

# if(this){
#   then 
# } else if(this){
#   then
# } else {
#   then
# }


# else and else if statements are optional. 

if(colour == "green"){
  print()
} else if(colour=="lilac"){
  print("beautiful")
}

# Often loops and if statements can be usefully combined and nested. Below, we expect certain files, and want to 
# complete the set (if running a simulation, for instance).

existing_files = Sys.glob("fits/*.rds")
still_to_do = data.frame()
already_done = data.frame()
for(condition1 in c("c1a","c1b","c1c","c1d")){
  for(condition2 in c("c2a","c2b","c2c")){
    filename = paste0("fits/",condition1,"_",condition2,".rds")
    if(!filename %in% existing_files){
      still_to_do <- bind_rows(still_to_do,
                               data.frame(condition1 = condition1,
                                          condition2 = condition2,
                                          filename = filename))
    } else {
      already_done <- bind_rows(already_done,
                               data.frame(condition1 = condition1,
                                          condition2 = condition2,
                                          filename = filename))
    }
  }
}
# now we would do stuff with the data.frame of conditions still to do.

# Another useful type of loop is a while loop.

reject = T
x = 0
while(reject){
  print(x)
  x = x + 2
  if(x > 12){
    reject = F
  }
}

# it is not obligatory, but conventional, to indent loop and if constructions.
# In R studio this happens mostly automatically. If you select a block of code, ctrl-I / apple-I re-indents the code for you.

# it is also possible to 'fold' the code to make it more legible, by clicking the triangles that appear next to line numbers where
# a { } chunk begins


# there is another type of conditional `ifelse()`, which is handy in mutate and transmute calls:
# ifelse(condition, return_if_true, return_if_false). 
# it returns a vector, so it can be used to add a column in a mutate call, for instance.

# Another handy function is `cut(vector, breaks, labels).
# This transforms a numeric vector into a factor, by labeling values between 'break' points.
# Below, we specify that we should group the jurors by age catgories.
# it is also possible to cut a numeric vector into n pieces (derived from the min and the max). 

jury %>% mutate(old = ifelse(Age>40,T,F),
                age_group = cut(Age,breaks = c(0,25,35,45,55,65,99),labels = c("<25","<35","<45","<55","<65",">66")),
                age_group2 = cut(Age,breaks = 6),
                recode(Gender,"Male"="m","Female"="f"))

# 

sample_n(final_2016,4)

# mini-assignment 3 -------------------------------------------------------

load("session_2/SUBTLEX-NL.cd-above2.with-POS.Rdata")
nouns <- subtlex.nl.cdgt2.withpos %>% filter(dominant.pos=="N",!is.na(dominant.pos.freq)) %>% filter(dominant.pos.freq>60 & dominant.pos.freq<100)

# Use a loop and conditionals to create 12 lists of 50 nouns (i.e. a list of 12 data.frames) that are balanced in frequency.
# (i.e. have similar mean and s.d.).

# functions ---------------------------------------------------------------

# A function is a reausable chunk of code that takes arguments, does something with them, and returns a result.

# We call functions with code of the following type:

# name_of_function(argument1, argument2)

# look familiar? most things we have used so far are functions, defined in base R or in packages that we have loaded.

# we can also define our own functions, like so:

# name_of_function <- function(argument1, argument2 = default){ 
#   do stuff
#   return(something)
# }

do_something <- function(argument1, argument2 = 45){
  if(is.numeric(argument1)&is.numeric(argument2)){
    if(argument1%%3 == 0){
      output = as.numeric(argument1) + argument2
    } else {
      output = as.numeric(argument1) / argument2
    }
    return(output)
  } else {
    stop("arguments should be numeric")
  }
}

retrieve_points <- function(rank){
  if(rank==1){
    return(12)
  } else if (rank==2){
    return(10)
  } else if (rank>=3&rank<=10){
    return(10 + (1 - rank))
  } else {
    return(0)
  }
}

do_something(3,5)
do_something(3)
do_something(3,"5")

retrieve_points(4)

# apply, sapply -----------------------------------------------------------

# apply and sapply are useful functions. There are also other variants, but their functions are 

# We'll start with sapply(vector, function). 

sapply(scores_by_juror$rank,retrieve_points)

# what sapply does is take each element of a vector and "apply" the specified function to it. The function
# is specified without brackets. Then, all the results are concatenated together. The function is therefore 
# equivalent to:

scores <- c()
for(rank in scores_by_juror$rank){
  scores <- append(scores, retrieve_points(rank))
}
scores

# sapply is typically much quicker than a for loop.

# apply(array, margin, function) is similar, but works on an array or a data.frame. The function is applied either to each row, or to each column.
# You have to specify the direction to loop over (the margin). 1 = rows, 2 = columns

squish_function <- function(x){
  paste0(x,collapse = "")
}

apply(scores_by_juror,1,squish_function)


# dplyr::do ---------------------------------------------------------------

# dplyr::do is like a super-powered apply. It follows the grouping set in your data, and for each group splits
# off a the relevant chunk of data, does something to it, then reconstructs a data.frame, containing the grouping 
# variables and data that your function returns. The function should therefore expect a data.frame, and return a data.frame.

# here, we'll check to see if jurors have a preference or dispreference for the entries of their neighbours. We'll run a 
# quick and dirty t-test to test the strength of their (dis)preference.

borders <- read.csv("session_2/eurovision/borders.csv",sep = "")

# first we construct a function, that takes a data.frame and returns a data.frame

check_juror_ranks <- function(x){
  ranks_neighbours <- x %>% filter(neighbour) # filter ranks assigned by this juror to neighbours
  ranks_not_neighbours <- x %>% filter(is.na(neighbour))
  if(nrow(ranks_neighbours)>1&nrow(ranks_not_neighbours)>1){
    result <- t.test(ranks_neighbours$rank,ranks_not_neighbours$rank)
    return(data.frame(neighbours=nrow(ranks_neighbours),
                      not_neighbours=nrow(ranks_not_neighbours),
                      t=result$statistic,
                      p=round(result$p.value,5)))
  } else { # not enough observations to run t.test, so return NA values
    return(data.frame(neighbours=nrow(ranks_neighbours),
                      not_neighbours=nrow(ranks_not_neighbours),
                      t=NA,
                      p=NA))
  }
}


neighbour_preferences <- left_join(scores_by_juror_details,borders) %>% # join data.frame of bordering countries
  group_by(from,name) %>% # we want to test each juror's scores. We want to know which country they come from
  do(check_juror_ranks(.)) # run function. The . refers to the data passed by do, not really sure why it is needed.

neighbour_preferences <- neighbour_preferences %>%
  ungroup() %>% # otherwise correction for multiple comparisons doesn't work
  mutate(corrected_p = p.adjust(p,method = "BH")) # do Benjamini & Hochberg (1995) correction


