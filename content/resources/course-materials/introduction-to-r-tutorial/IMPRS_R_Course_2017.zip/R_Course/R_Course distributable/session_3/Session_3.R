
## Hans Rutger Bosker, Max Planck Institute, Nijmegen
## Joe Rodd, Max Planck Institute, Nijmegen
## R tutorial, leture 3, 6 June 2017
## HansRutger.Bosker@mpi.nl
## Joe.Rodd@mpi.nl




## FOR INSTRUCTOR:
# CLASSROOM PRESENTATION PREFERENCES
# increase font size (18+) and adjust color (red4) for Console window
# R win: use Rgui > preferences > gui
# Rstudio: tools > options > appearance

# This session includes a !!!very basic!!! introduction to linear mixed models using lme4 package.

# Materials adapted from Bodo Winter:
# Winter, B. (2013). Linear models and linear mixed effects models in R with linguistic applications. arXiv:1308.5499.
# [http://arxiv.org/pdf/1308.5499.pdf]



# Session 3 ---------------------------------------------------------------

# Say, you're interested in pitch variation between and within talkers
# and you want to find out whether politeness has an effect of pitch
# while controlling for sex differences, and talker and item variation.
# So you run an experiment where you have different speakers (male and female)
# produce speech in different registers (formal, informal)
# in different speech scenarios ("ask for favor"; "excusing for being late"; etc.).
# You then calculate their pitch in Praat and store the data in a data file called "politeness_data.csv"

politeness <- read.csv(file="session_3/politeness_data.csv", header=T)


# data exploration mini-exercises -----------------------------------------

####### How many speakers (M/F) did you record?
####### How many observations are there for each talker?
####### Are there any missing values?
####### What's the average pitch for the females vs. the males?
####### What's the average pitch in the polite vs. the informal speech conditions?


# Let's add some hypothetical data on participant age as well:
subjectinfo <- data.frame(subject=c("F1","F2","F3","M3","M4","M7"), age=c(22,18,NA,26,28,34))

####### Merge the subjectinfo object with the politeness object

library(dplyr)

politeness <- left_join(politeness,subjectinfo)


# Mixed effects models ----------------------------------------------------

# As you saw in the data exploration exercises above,
# there's considerable variation between talkers (even within the same sex)
# and there's also some variation between items.
# Instead of averaging over these sources of variation,
# mixed models allow you to take these sources of variation into account.

# The functions required to run mixed models in R are found in the lme4 package
require(lme4)
?lme4
citation("lme4")

# OK, so let's build our first model.
# Models always have the following structure:
# modelname <- lmer(depvar ~ fixedeffects + (1|randomeffects), data=objectname, REML=F)
# >>> We'll come back to the REML=F bit in a moment...

m1 <- lmer(frequency ~ age + (1|subject) + (1|scenario), data=politeness, REML=F)
summary(m1)

####### OUTPUT:
#  Linear mixed model fit by maximum likelihood  ['lmerMod']
#  Formula: frequency ~ age + (1 | subject) + (1 | scenario)
#  Data: politeness
#  
#  AIC      BIC   logLik deviance df.resid 
#  676.3    687.5   -333.2    666.3       64 
#  
#  Scaled residuals: 
#    Min       1Q   Median       3Q      Max 
#  -2.19193 -0.64149 -0.02127  0.68865  2.47480 
#  
#  Random effects:
#    Groups   Name        Variance Std.Dev.
#  scenario (Intercept) 145.26   12.052  
#  subject  (Intercept)  39.84    6.312  
#  Residual             797.03   28.232  
#  Number of obs: 69, groups:  scenario, 7; subject, 5
#  
#  Fixed effects:
#    Estimate Std. Error t value
#  (Intercept) 446.1206    21.7057   20.55
#  age         -10.3406     0.8115  -12.74
#  
#  Correlation of Fixed Effects:
#    (Intr)
# age -0.956

# Let's slowly go through the output that R gives you.

# It first says that the model was fit by maximum likelihood (ML), not by REML (dictated by REML=F)
# Again, we'll come back to model fitting later.

# After stating the formula and dataset that gave rise to the model,
# it prints several indicators of how well the estimated model
# fit the actually observed data. You'll find that AIC (Akaike's Information Criterion), BIC,
# and log-likelihood are all fit parameters that are used in the literature. I usually use logLik.
# logLik values cannot be interpreted as absolute values (determined by many factors, such as data scaling, etc.)
# but they can be compared across models, as we'll see in a minute.
# The important thing to remember about logLik is that
# the closer to zero, the better the model fits your data.
# So a model with logLik = -330.4 is (numerically) a better fit to the data than a model with logLik = -333.2

# After the scaled residuals, we get the random effects structure.
# It provides information on three random effects: scenario, subject, and Residual.
# Residual is the residual error, the unexplained variance.
# subject is the variance explained by between-subject variation.
# scenario is the variance explained by between-scenario (=within-talker) variation.

# After a summary of the data (69 observations in total (why not 84? the data structure has 84 rows??), with 5 subjects, and 7 scenarios)
# you find the fixed effects.
# These should be read as in a standard regression analysis:
# the depvar can be estimated by a combination of the intercept & the slope of the age effect.
# The intercept gives the predicted value of the depvar pitch if all predictors in the model are 0.
# That is, the model predicts that a speaker with age=0 has a pitch of 446.1 Hz.
# The effect of age indicates how much pitch decreases if age is increased by 1.
# So a speaker with age=1 is predicted to have a pitch of 446.1 - 10.3 = 435.8 Hz
# A speaker with age=18 is predicted to have a pitch of 446.1 - (10.3*18) = 260.7 Hz.
# Finally, the last column shows the t-value for each predictor including the intercept.

# There is a lot of debate about how to interpret the statistical significance of fixed effects.
# Baayen (2008, page 270) says: "Since for large numbers of degrees of freedom (>100)
# the t distribution approximates the normal distribution, a simple way of assessing
# significance at the 5% significance level is to check whether |t|>2"


# There are a few things to be adjusted about the initial model m1.
# First, the predictor age has an intercept at 0 which is meaningless.
# So we rescale the predictor age:
?scale
politeness$age_scaled <- scale(politeness$age)

m2 <- lmer(frequency ~ age_scaled + (1|subject) + (1|scenario), data=politeness, REML=F)
summary(m2)

# You'll find that the fit to the data (logLik) and the random effects have not changed
# because we didn't change anything interesting about the data, we only rescaled some predictor.
# However, the Intercept estimate has changed. The intercept gives the depvar pitch value
# if all predictors are at zero. This time, age_scaled=0 means the mean age of all participants.
mean(politeness$age, na.rm=T)
# So the intercept says that a talker with age = 25.6 years has a pitch of 181.4 Hz.
# The effect of age_scaled is also different from the effect of age in m1.
# The estimate shows the decrease in pitch in Hz that is predicted if one sd of age is added.
sd(politeness$age, na.rm=T)
# So a talker with age 25.6+5.46 = 31 would have a pitch of 181.6-56.5 = 125.1 Hz




# The predictor age is a nice example to start interpreting lmers because it is a continuous predictor.
# It's also possible to use categorical predictors, such as attitude in our case.

m3 <- lmer(frequency ~ attitude + (1|subject) + (1|scenario), data=politeness, REML=F)
summary(m3)

# Note that the fixed effects reports an effect of "attitudepol".
# Attitude has two levels: inf(ormal) and pol(ite).
# Because inf comes earlier in the alphabet than pol, inf is taken as the intercept.
# Therefore, we should read the Intercept estimate as the estimated pitch
# for a speaker in an informal speaking situation.
# The effect attitudepol then shows how much pitch changes when going to a formal situation.
# It's possible to change the intercept of a categorical predictor by releveling the factor:

politeness$attitude_i_pol <- relevel(politeness$attitude, "pol")
m4 <- lmer(frequency ~ attitude_i_pol + (1|subject) + (1|scenario), data=politeness, REML=F)
summary(m4)
# You'll find that m4 is mathematically equivalent to m3 (same logLik etc.)
# but only has a different fixed effects structure.





# Although we are now interpreting our models correctly
# the models themselves are much too simplistic.
# Pitch is of course not only determined by a speaker's age or a given speech register,
# but also by that speaker's sex, the speech task, potential hangovers, etc.
# So let's build some more realistic models!

m5 <- lmer(frequency ~ gender + attitude + (1|subject) + (1|scenario), data=politeness, REML=F)
summary(m5)

# You'll notice that the variation attributed to between-subject variation in the Random structure
# has decreased considerably by adding the gender predictor.
# You'll find that the logLik of m5 is closer to zero than m3, suggesting it's a better fit to the data.
# Let's see whether it is actually statistically significantly better than m3
anova(m3, m5)
# This shows that m5 is a significantly better fit than m3.
# >>> Note that comparing models with the anova command is only valid
# >>> if (1) one model is nested in the other, and
# >>> if (2) both models were estimated with ML, not REML, so always use REML=F
# This anova method can also be used to report statistical significance (i.e., instead of |t|>2)

# How about an interaction between age and attitude?
# That is, does the effect of attitude differ between males and females?
m6 <- lmer(frequency ~ gender * attitude + (1|subject) + (1|scenario), data=politeness, REML=F)
summary(m6)
# Given the low t value, probably not. Let's compare with m5.
anova(m5, m6)
# Nope, so let's ignore the interaction term!






# So far we've only been running random intercept models.
# That is, we only included random intercept for subjects and items.
# These can be inspected by typing:
coef(m5)
# This shows the estimated intercept for each subject and for each scenario separately.
# However, it also shows that the effect of attitude is identical in all subjects and all scenarios.
# But maybe some pps were simply more polite than others making an equal effect of politeness unlikely.
# So we also need to include random slopes for attitude:
m5_ranslopes <- lmer(frequency ~ gender + attitude + (1 + attitude | subject) + (1 + attitude | scenario), data=politeness, REML=F)
coef(m5_ranslopes)
# This time, we also get different estimates for the effect of attitude per scenario and per subject.
# However, they're still quite similar across the board, so there's likely something real going on:
summary(m5)
summary(m5_ranslopes)
# The t value of attitude is still very comparable!
# Can we get a p-value to support that? Well, we'll need a new null model
m5_ranslopes_null <- lmer(frequency ~ gender + (1 + attitude | subject) + (1 + attitude | scenario), data=politeness, REML=F)
anova(m5_ranslopes_null, m5_ranslopes)
# Yes, still OK!





# So how do write these things up? Here's an examples:
#
#  "We used R (R Core Team, 2012) and lme4 (Bates, Maechler & Bolker, 2012)
#  to perform a linear mixed effects analysis of the relationship
#  between pitch and politeness. As fixed effects, we entered politeness and
#  gender (without interaction term) into the model. As random effects, we
#  had intercepts for subjects and items, as well as by-subject and by-item
#  random slopes for the effect of politeness. P-values were obtained by
#  likelihood ratio tests of the full model with the predictor politeness
#  against the null model without predictor politeness.
#  We observed that politeness affected pitch (X2 (1)=6.708, p=0.009), lowering it by
#  about 19.7 Hz +/- 5.9 (standard errors)."





# FURTHER READING ----------------

#More detailed information regarding the use of linear mixed models can be found here:

#R. Harald Baayen's book: "Analyzing linguistic data", 2008
#http://www.sfs.uni-tuebingen.de/~hbaayen/publications/baayenCUPstats.pdf
#> Great intro, with R code in the text, but already slightly outdated...

#in these specialist papers
#> Baayen, R. H., Davidson, D. J., & Bates, D. M. (2008). Mixed-effects modeling with crossed random effects for subjects and items. Journal of memory and language, 59(4), 390-412.
#> Quen�, H., & Van den Bergh, H. (2008). Examples of mixed-effects modeling with crossed random effects and with binomial data. Journal of Memory and Language, 59(4), 413-425.
#> Quen�, H. (2008). Multilevel modeling of between-speaker and within-speaker variation in spontaneous speech tempo. The Journal of the Acoustical Society of America, 123(2), 1104-1113.

#on Hugo Quen�'s website: www.hugoquene.nl
#> has a lot of course materials for statistics courses
#> also introduction to using R (pdf) written for EMLAR

# bodowinter.com for step-by-step guide for regression analysis on politeness_data.csv






















# effects package ---------------------------------------------------------


library(ggplot2)

# we can use the effects package to extract the fits and confidence intervals of the model for each effect.
library(effects)

# effect("contrast", model) %>% as.data.frame()

attitude_fits <- effect("attitude",mod = m5_ranslopes) %>% as.data.frame()
gender_fits <- effect("gender",mod = m5_ranslopes) %>% as.data.frame()

# More ggplot2 ------------------------------------------------------------

# The effects extracted by the effects package are suitable for plotting. If we want to show real data as
# a violin and the fits and CIs, we need to plot two different datasets.
# We can specify the dataset to use in each of the layers / geoms independently, by providing a data=
# argument in each geom.

# Here's how I construct such a plot:

ggplot()+
  geom_violin(aes(x=gender,y=frequency,fill=gender),alpha=0.6,data=politeness)+
  # alpha = 0.6 to improve the visibility of the stripe
  geom_rect(aes(ymax=upper,ymin=lower,fill=gender),xmin=-Inf,xmax=Inf,alpha=0.3,data = gender_fits)+
  # Here we are assigning the aesthetics xmin and xmax (left and right edges of the box) rather than mapping them,
  # so they come outside the aes() call. -Inf means the left edge of the plot (or facet), Inf means the right edge. So we
  # specify that the box should occupy the full width of the facet.
  geom_hline(aes(yintercept=fit),data = gender_fits)+
  geom_point(aes(x=gender,y=fit),data = gender_fits)+
  coord_trans(y = "log")
# frequencies make sense on a log scale, perceptually. Remember that coord transforms whats plotted rather than the mapping to
# space. This usually makes more sense than specifying a log scale.


# The layers are drawn in the order that you specify them (from bottom to top). So when you have several, you need to think
# about which order they should be drawn:

ggplot()+
  geom_hline(aes(yintercept=fit),data = gender_fits)+
  geom_point(aes(x=gender,y=fit),data = gender_fits)+
  geom_rect(aes(ymax=upper,ymin=lower,fill=gender),xmin=-Inf,xmax=Inf,alpha=0.3,data = gender_fits)+
  geom_violin(aes(x=gender,y=frequency,fill=gender),alpha=0.6,data=politeness)+
  coord_trans(y = "log") # less pretty.

# it is possible to define a scale outside of the context of a plot, so you can re-use it.
# this is a good idea if you are going to produce several related plots and you want the colours to consistently
# refer to the same conditions, for instance.


scale_gender_fill <- scale_fill_manual(name = "Gender",
                                         values = c("F"="#CC0000","M"="#33CCCC"),
                                         labels=c("Female","Male"))

# when we're defining a scale, we can also relabel the scale itself (name = )  and the levels (labels =).


ggplot()+
  geom_violin(aes(x=gender,y=frequency,fill=gender),alpha=0.6,data=politeness)+
  # alpha = 0.6 to improve the visibility of the stripe
  geom_rect(aes(ymax=upper,ymin=lower,fill=gender),xmin=-Inf,xmax=Inf,alpha=0.3,data = gender_fits)+
  scale_y_continuous(name="Pitch (Hz)")+
  scale_gender_fill+
  # Here we are assigning the aesthetics xmin and xmax (left and right edges of the box) rather than mapping them,
  # so they come outside the aes() call. -Inf means the left edge of the plot (or facet), Inf means the right edge. So we
  # specify that the box should occupy the full width of the facet.
  geom_hline(aes(yintercept=fit),data = gender_fits)+
  geom_point(aes(x=gender,y=fit),data = gender_fits)+
  coord_trans(y = "log")


# we can use coords_cartesian() to zoom in to part of a plot

ggplot()+
  geom_violin(aes(x=gender,y=frequency,fill=gender),alpha=0.6,data=politeness)+
  geom_rect(aes(ymax=upper,ymin=lower,fill=gender),xmin=-Inf,xmax=Inf,alpha=0.3,data = gender_fits)+
  scale_gender_fill+
  scale_y_continuous(name="Pitch (Hz)")+
  geom_hline(aes(yintercept=fit),data = gender_fits)+
  geom_point(aes(x=gender,y=fit),data = gender_fits)+
  coord_cartesian(ylim = c(120,250))

# doing it this way crops the plot without removing data.
# it is also possible to do this in the scale, but that removes data before the geoms are 
# calculated, so is nearly always going to result in a misleading result:

ggplot()+
  geom_violin(aes(x=gender,y=frequency,fill=gender),alpha=0.6,data=politeness)+
  geom_rect(aes(ymax=upper,ymin=lower,fill=gender),xmin=-Inf,xmax=Inf,alpha=0.3,data = gender_fits)+
  scale_gender_fill+
  scale_y_continuous(name="Pitch (Hz)",limits = c(120,250))+
  geom_hline(aes(yintercept=fit),data = gender_fits)+
  geom_point(aes(x=gender,y=fit),data = gender_fits)


# With the effects package, we can also extract the fits for combinations of predictors, and plot these in
# much the same way:

fits <- effect("gender:attitude",mod = m5_ranslopes) %>% as.data.frame()

ggplot()+
  geom_violin(aes(x=attitude,y=frequency,fill=attitude),data=politeness,alpha=0.6)+
  geom_rect(aes(ymax=upper,ymin=lower,fill=attitude),xmin=-Inf,xmax=Inf,alpha=0.3,data=fits)+
  geom_hline(aes(yintercept=fit),data=fits)+
  geom_point(aes(x=attitude,y=fit),data=fits)+
  scale_x_discrete(name="Speaking style",labels=c("Informal","Polite"))+
  facet_wrap(~gender)+
  coord_trans(y = "log")


# it is possible to store a plot as an object to allow further modification of it:

plot_style_by_gender <- ggplot()+
  geom_violin(aes(x=attitude,y=frequency,fill=attitude),data=politeness,alpha=0.6)+
  geom_rect(aes(ymax=upper,ymin=lower,fill=attitude),xmin=-Inf,xmax=Inf,alpha=0.3,data=fits)+
  geom_hline(aes(yintercept=fit),data=fits)+
  geom_point(aes(x=attitude,y=fit),data=fits)+
  scale_x_discrete(name="Speaking style",labels=c("Informal","Polite"))+
  facet_wrap(~gender)+
  coord_trans(y = "log")


# ggplot also has an extensive theming system, allowing customising of nearly all the graphical properties of 
# a plot.

# the simplest changes come from selecting a different built in theme, options are:
#     - theme_grey()    the default
#     - theme_bw()
#     - theme_classic()
#     - theme_minimal()
#     plus a few more

plot_style_by_gender+theme_bw()

plot_style_by_gender+theme_classic()
plot_style_by_gender+theme_minimal()

# I think that these generally look worse than the default grey.

# You might want to change the font of a plot:

plot_style_by_gender+theme(text = element_text(family="Times"))

plot_style_by_gender+theme_bw()+theme(text = element_text(family="Times"))
# they are applied in order, so select a default theme first, then modify it:
plot_style_by_gender+theme(text = element_text(family="Times"))+theme_bw()

# all kinds of abominations are possible  
plot_style_by_gender+theme(text = element_text(family="Times",colour = "red",size = 17,angle = 34))


# Mini assignment -----------------------------------------------------------

# reproduce Speaking_style_plot.pdf. The y-axis is log transformed, the colours are 
# #FF3300 and #6666FF. The page is 6 x 6 inches.

